//
//  ViewController.swift
//  GAME
//
//  Created by Admin (ADAM) on 20/01/2018.
//  Copyright © 2018 Admin (ADAM). All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    private var gameModel = GameModel();
    
    var totalhealth = Double(2560);
    var playerAttacks = false;
    var harm = 0;
   
    @IBOutlet weak var display: UILabel!

    
    
    @IBAction func attack(_ sender: UIButton) {
        
        if sender.currentTitle == "Tornado"
        {
             harm = 70;
            gameModel.setSkill("Tornado")
        }
        if sender.currentTitle == "Chaos Meteor"
        {
            harm = 180;
            gameModel.setSkill("Chaos Meteor")
        }
        if sender.currentTitle == "Defeaning Blast"
        {
            harm = 253;
             gameModel.setSkill("Defeaning Blast")
        }
        if sender.currentTitle == "Sun Strike"
        {
            harm = 537;
             gameModel.setSkill("Sun Strike")
        }
        
        gameModel.computeHealth(health: Double(totalhealth), damage: Double(harm))
        
        totalhealth = gameModel.remainingHealth!
        
        
        if totalhealth>=0{
             display.text = String(totalhealth);
        }
        else{
            display.text = "0";
        }
    }
    
}


//
//  GameModel.swift
//  GAME
//
//  Created by Admin (ADAM) on 20/01/2018.
//  Copyright © 2018 Admin (ADAM). All rights reserved.
//

import Foundation

struct GameModel {
    private var skillName: String?;
    
    private var returningValue: Double?;
    
    var remainingHealth: Double? 
    
    
    mutating func setSkill(_ skill: String){
        skillName = skill;
    }
    
    mutating func computeHealth(health: Double, damage: Double) {
        if (skillName == "Tornado"){
            remainingHealth = health - damage;
            
        }
        if (skillName == "Chaos Meteor"){
            remainingHealth = health - damage;
        }
        if (skillName == "Defeaning Blast"){
            remainingHealth = health - damage;
        }
        if (skillName == "Sun Strike"){
            remainingHealth = health - damage;
        }
    }
}


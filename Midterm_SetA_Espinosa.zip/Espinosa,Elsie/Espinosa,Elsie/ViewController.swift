//
//  ViewController.swift
//  Espinosa,Elsie
//
//  Created by ADMIN on 1/20/18.
//  Copyright © 2018 ADMIN. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

 
    @IBOutlet var decreaseLife: [UILabel]!

   
    
    @IBAction func touchPower(_ sender: UIButton) {
        let power = sender.currentTitle!
        if GamerIsAttacking {
            let PowerDecreaselife = decreaseLife! . Power!
            decreaselife! . Power! = PowerDecreaselife - touchPower
            
        } else {
            decreaseLife! . Power! = Power
            GamerIsAttacking = true
        }
        
    }

    
    @IBAction func attacks(_ sender: UIButton) {
        
        if attacks == "+" {
            returningValue = attack1 - attack2
        }
        else if attacks == damage
    }
}

